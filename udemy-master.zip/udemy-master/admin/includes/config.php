<?php 

// Database Connection Constants

define("DB_HOST", "localhost");
define("DB_USER", "udemy");
define("DB_PASS", "xxxxxx");
define("DB_NAME", "gallery_udemy");


?>